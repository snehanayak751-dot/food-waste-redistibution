from django.contrib import admin
from django.urls import path
from django.contrib.auth import views as auth_views
from foodapp import views

urlpatterns = [
    # Admin
    path('admin/', admin.site.urls),

    # Home & Profile
    path('', views.home, name='home'),
    path('profile/', views.profile_view, name='profile_page'),

    # Registration
    path('ngo/register/', views.register_ngo, name='register_ngo'),
    path('volunteer/register/', views.register_volunteer, name='register_volunteer'),

    # Login/Logout
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),

    # Food Logic
    path('food/add/', views.add_food, name='add_food'),
    path('food/list/', views.food_list, name='food_list'),
    path('food/request/', views.request_food, name='request_food'),

    # Volunteer Operations
    path('volunteer/dashboard/', views.volunteer_dashboard, name='volunteer_dashboard'),
    path('accept-delivery/<int:request_id>/', views.accept_delivery, name='accept_delivery'),
    path('mark-delivered/<int:request_id>/', views.mark_delivered, name='mark_delivered'),
]