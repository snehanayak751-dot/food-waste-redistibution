from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User  # <--- THIS IS THE MISSING LINE
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from .models import FoodItem, NGO, Volunteer, FoodRequest
from .forms import FoodForm

def home(request):
    total_batches = FoodItem.objects.count()
    available_now = FoodItem.objects.filter(status='Available').count()
    successful_deliveries = FoodRequest.objects.filter(status='delivered').count()
    recent_food = FoodItem.objects.filter(status='Available').order_by('-id')[:5]

    return render(request, 'home.html', {
        'total_batches': total_batches,
        'available_now': available_now,
        'successful_deliveries': successful_deliveries,
        'recent_food': recent_food,
    })

def food_list(request):
    all_food = FoodItem.objects.filter(status='Available') 
    return render(request, 'food_list.html', {'foods': all_food})

def add_food(request):
    if request.method == "POST":
        form = FoodForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('food_list') 
    else:
        form = FoodForm()
    return render(request, 'add_food.html', {'form': form})

@login_required




# --- NGO REGISTRATION ---
def register_ngo(request):
    if request.method == "POST":
        # We only get what is actually in your HTML form
        uname = request.POST.get('username')
        pword = request.POST.get('password')
        n_name = request.POST.get('ngo_name')
        cont = request.POST.get('contact')
        addr = request.POST.get('address')

        # This prevents the "MultiValueDictKeyError"
        if not uname or not pword:
            return render(request, 'ngo_register.html', {'error': 'Username and Password are required.'})

        try:
            # 1. Create the User account (Login info)
            # Notice: email is NOT included here anymore
            user = User.objects.create_user(username=uname, password=pword)
            
            # 2. Create the NGO profile details
            NGO.objects.create(
                user=user, 
                ngo_name=n_name, 
                phone=cont,
                address=addr
            )
            
            # 3. Log the user in and go home
            login(request, user)
            return redirect('home')
            
        except Exception as e:
            # This catches if the username is already taken
            return render(request, 'ngo_register.html', {'error': str(e)})

    return render(request, 'ngo_register.html')
def register_volunteer(request):
    if request.method == "POST":
        u = request.POST.get('username')
        p = request.POST.get('password')
        ph = request.POST.get('phone')
        ct = request.POST.get('area')

        if User.objects.filter(username=u).exists():
            return render(request, 'volunteer_register.html', {'error': 'Username already exists!'})

        user = User.objects.create_user(username=u, password=p)
        Volunteer.objects.create(user=user, phone=ph, city=ct)
        
        login(request, user)
        return redirect('home')
    return render(request, 'volunteer_register.html')

@login_required
@login_required
@login_required
@login_required
def volunteer_dashboard(request):
    # Data for the "Available" table
    pending = FoodRequest.objects.filter(assigned_to__isnull=True, status='pending')
    
    # Data for the "History" table
    tasks = FoodRequest.objects.filter(assigned_to=request.user)
    
    # Counter logic
    count = tasks.filter(status='delivered').count()

    return render(request, 'volunteer_dashboard.html', {
        'pending_requests': pending,
        'my_tasks': tasks,
        'success_count': count
    })

@login_required
@login_required
@login_required
def accept_delivery(request, request_id):
    # 1. Get the request
    food_req = get_object_or_404(FoodRequest, id=request_id)
    
    # 2. Check if it's still available to claim
    if food_req.assigned_to is None:
        # Assign it to the volunteer
        food_req.assigned_to = request.user
        
        # IMMEDIATELY mark as delivered so the counter increases
        food_req.status = 'delivered' 
        food_req.save()
        
        # Update the food item so it vanishes from Available Food
        food_item = food_req.food
        food_item.status = 'Delivered'
        food_item.save()
        
    return redirect('volunteer_dashboard')

@login_required
def mark_delivered(request, request_id):
    food_request = get_object_or_404(FoodRequest, id=request_id)
    
    # 1. Complete the request
    food_request.status = 'delivered'
    food_request.save()
    
    # 2. Update the food item to final state
    food_item = food_request.food
    food_item.status = 'Delivered'
    food_item.save()
    
    return redirect('volunteer_dashboard')

@login_required
def profile_view(request):
    user = request.user
    ngo_profile = None
    volunteer_profile = None

    # Check if the user has an NGO profile
    if hasattr(user, 'ngo'):
        ngo_profile = user.ngo
    
    # Check if the user has a Volunteer profile
    if hasattr(user, 'volunteer'):
        volunteer_profile = user.volunteer

    return render(request, 'profile.html', {
        'user': user,
        'ngo': ngo_profile,
        'volunteer': volunteer_profile
    })
# --- REGISTRATION LOGIC ---

def register_ngo(request):
    if request.method == "POST":
        # Using .get() prevents crashes if a field is missing
        uname = request.POST.get('username')
        pword = request.POST.get('password')
        n_name = request.POST.get('ngo_name')
        cont = request.POST.get('contact')
        addr = request.POST.get('address')

        # Simple validation
        if not uname or not pword:
            return render(request, 'ngo_register.html', {'error': 'Username and password are required.'})

        try:
            # 1. Create the Auth User (NOTICE: email is removed from here)
            user = User.objects.create_user(username=uname, password=pword)
            
            # 2. Create the NGO profile
            NGO.objects.create(
                user=user, 
                ngo_name=n_name, 
                phone=cont,
                address=addr
            )
            
            # 3. Log them in and redirect home
            login(request, user)
            return redirect('home')
            
        except Exception as e:
            # This handles if the username is already taken
            return render(request, 'ngo_register.html', {'error': f"Registration failed: {str(e)}"})

    return render(request, 'ngo_register.html')

def register_volunteer(request):
    if request.method == "POST":
        uname = request.POST.get('username')
        pword = request.POST.get('password')
        phone = request.POST.get('phone')
        area = request.POST.get('area')

        if not uname or not pword:
            return render(request, 'volunteer_register.html', {'error': 'Credentials required'})

        try:
            # 1. Create the Auth User
            user = User.objects.create_user(username=uname, password=pword)
            
            # 2. Create the Volunteer Profile
            Volunteer.objects.create(
                user=user,
                phone=phone,
                city=area
            )
            
            # 3. Log them in
            login(request, user)
            return redirect('home')
            
        except Exception as e:
            return render(request, 'volunteer_register.html', {'error': str(e)})

    return render(request, 'volunteer_register.html')
# --- PROTECTED DASHBOARDS ---

@login_required
@login_required
def request_food(request):
    # 1. Verify NGO Profile exists
    try:
        ngo_profile = request.user.ngo
    except Exception:
        return render(request, 'home.html', {'error': 'You must be registered as an NGO to request food.'})

    if request.method == 'POST':
        f_id = request.POST.get('food_id')
        reaz = request.POST.get('reason', 'General Request') # Default value if empty
        
        if not f_id:
            return render(request, 'request_food.html', {'error': 'Please select a food item.'})

        try:
            food_item = get_object_or_404(FoodItem, id=f_id)
            
            # 2. Manual Save to ensure MySQL accepts the data
            new_req = FoodRequest()
            new_req.food = food_item
            new_req.ngo_name = ngo_profile.ngo_name
            new_req.address = ngo_profile.address
            new_req.reason = reaz
            new_req.status = 'pending'
            # assigned_to is left as None/Null intentionally here
            
            new_req.save() # This sends the INSERT command to XAMPP

            # 3. Update the food item status
            food_item.status = 'Requested'
            food_item.save()
            
            return redirect('volunteer_dashboard')
            
        except Exception as e:
            # THIS IS CRUCIAL: Check your VS Code terminal for this print!
            print(f"DATABASE ERROR: {e}")
            return render(request, 'request_food.html', {'error': f'Database Error: {e}', 'available_food': FoodItem.objects.filter(status='Available')})

    # GET request logic
    available_food = FoodItem.objects.filter(status='Available')
    return render(request, 'request_food.html', {'available_food': available_food})

@login_required
@login_required
def volunteer_dashboard(request):
    # 1. Look for requests that HAVE NOT been assigned to anyone yet
    # This is the "Open Pool" of tasks
    pending_requests = FoodRequest.objects.filter(assigned_to__isnull=True, status='pending')
    
    # 2. Look for tasks ALREADY claimed by the logged-in volunteer
    my_tasks = FoodRequest.objects.filter(assigned_to=request.user)
    
    # 3. Count only the finished ones for the counter
    success_count = my_tasks.filter(status='delivered').count()

    return render(request, 'volunteer_dashboard.html', {
        'pending_requests': pending_requests,
        'my_tasks': my_tasks,
        'success_count': success_count
    })