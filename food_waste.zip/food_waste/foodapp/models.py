from django.db import models
from django.contrib.auth.models import User

# 1. Food Item Model
class FoodItem(models.Model):
    STATUS_CHOICES = [
        ('Available', 'Available'),
        ('Requested', 'Requested'),
        ('In Transit', 'In Transit'),
        ('Delivered', 'Delivered'),
    ]
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    quantity = models.CharField(max_length=100)
    donor_name = models.CharField(max_length=255, default="Restaurant")
    expiry_date = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Available')

    def __str__(self):
        return f"{self.name} ({self.status})"

# 2. NGO Profile
class NGO(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    ngo_name = models.CharField(max_length=200)
    address = models.TextField()
    phone = models.CharField(max_length=15)

    def __str__(self):
        return self.ngo_name

# 3. Volunteer Profile
class Volunteer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone = models.CharField(max_length=15)
    city = models.CharField(max_length=100)

    def __str__(self):
        return self.user.username

# 4. Food Request Model (The one that was missing)
class FoodRequest(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('claimed', 'Claimed'),
        ('delivered', 'Delivered'),
    ]
    food = models.ForeignKey(FoodItem, on_delete=models.CASCADE)
    ngo_name = models.CharField(max_length=200)
    address = models.TextField()
    reason = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    requested_at = models.DateTimeField(auto_now_add=True)
    assigned_to = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return f"Request for {self.food.name} by {self.ngo_name}"

# 5. Profile Model
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone = models.CharField(max_length=15)
    address = models.TextField()

    def __str__(self):
        return self.user.username