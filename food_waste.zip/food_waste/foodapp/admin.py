from django.contrib import admin
# Update this line to import FoodItem instead of Food
from .models import FoodItem, NGO, Volunteer, FoodRequest, Profile

# Register your models here.
admin.site.register(FoodItem)
admin.site.register(NGO)
admin.site.register(Volunteer)
admin.site.register(FoodRequest)
admin.site.register(Profile)